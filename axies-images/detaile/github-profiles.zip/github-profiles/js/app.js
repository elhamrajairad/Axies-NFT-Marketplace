const API_URL = "https://api.github.com/users/";

const btnSearch = document.querySelector("#btn-search");
const inputSearch = document.querySelector("#username");

const imgAvatar = document.querySelector("#avatar");

btnSearch.addEventListener("click", (event) => {
  // console.log({ input: inputSearch.value });

  let searchTerm = inputSearch.value;

  if (!searchTerm) {
    alert("haji in khaileee");
    return;
  }

  // 2 req: Sync / Async
  fetch(API_URL + searchTerm, { method: "GET" })
    .then(function (response) {
      return response.json();
    })
    .then((data) => {
      render(data);
    });
});

// function getUser(username) {}

function render(data) {
  const { avatar_url, hireable, following, followers, location, name } = data;
  imgAvatar.src = avatar_url;
}
